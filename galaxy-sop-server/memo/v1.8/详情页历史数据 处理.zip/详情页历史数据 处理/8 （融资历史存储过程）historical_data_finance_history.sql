CREATE DEFINER=`root`@`localhost` PROCEDURE `historical_data_finance_history`()
BEGIN
	
	 /*定义数据变量*/
	declare _id BIGINT(20);
	declare _project_id varchar(50);
    declare _field_1 VARCHAR(2000);
    declare _field_2 VARCHAR(2000);
    declare _field_3 VARCHAR(2000);
    declare _field_4 VARCHAR(2000);
    declare _field_5 VARCHAR(2000);
    declare _field_6 VARCHAR(2000);
    declare _field_7 VARCHAR(2000);
    declare _created_time BIGINT(20);
    declare _create_id BIGINT(20);
	declare historyData int;
	declare v_count int;
	declare s1 int;
    declare _title_id bigint(20);
    declare done int default false;
    
    /*查询历史数据中有哪些项目添加融资历史数据*/
	declare rs_cursor cursor for SELECT a.project_id, b.create_uid FROM fx_db.finance_history a left join fx_db.sop_project b  on a.project_id = b.id group by a.project_id;
	declare continue handler for not found set done=true;
	
    /*查询历史数据中有融资历史的项目个数用于下面循环处理*/
    set v_count = (select count(*) from fx_db.sop_project where id in(SELECT a.project_id id FROM fx_db.finance_history a left join fx_db.sop_project b  on a.project_id = b.id group by a.project_id));
    set s1 = 1;
	
    /*给出融资历史对应的全息报告题号*/
    set _title_id = 1903;
	
    /*取出全息报告中存储动态表格的数据库最大ID*/
	set _id = (select max(id) from fx_db.information_listdata);
	
	
    /*循环处理每个项目的融资历史*/
	open rs_cursor;
	cursor_loop:loop
		fetch rs_cursor into _project_id,_create_id;
		if done then
			leave cursor_loop;
		end if;
		
		set historyData = (select count(id) from fx_db.information_listdata where project_id = _project_id and title_id = _title_id);
		if historyData >= 1 then
			/*如果已录入信息，则在日志表里添加记录这个项目不需要处理*/
			insert into fx_db.historical_data_log (data_type, project_id) values ('融资历史', _project_id);
		end if;
		
		if historyData < 1 then
		
			insert into fx_db.information_listdata (project_id, title_id, field_1, field_2, field_3, field_4, field_5, field_6, field_7, is_valid, created_time, create_id) 
			select project_id,_title_id,finance_date, finance_from, finance_amount, finance_proportion,
			finance_amount/(finance_proportion/100) assessment,
			(CASE WHEN finance_unit = 1 THEN  2182 ELSE 2181 END) finance_unit,
			(case when(finance_status='financeStatus:0')  then 2184
			when(finance_status='financeStatus:1') then 2185    
			when(finance_status='financeStatus:2') then 2186 
			when(finance_status='financeStatus:3') then 2187
			when(finance_status='financeStatus:4') then 2188 
			when(finance_status='financeStatus:5') then 2189
			when(finance_status='financeStatus:6') then 2190
			when(finance_status='financeStatus:7') then 2191 
			when(finance_status='financeStatus:8') then 2192
			when(finance_status='financeStatus:9') then 2193 
			when(finance_status='financeStatus:10') then 2194
			when(finance_status='financeStatus:11') then 2195
			when(finance_status='financeStatus:12') then 2196 
			when(finance_status='financeStatus:13') then 2197 
			when(finance_status='financeStatus:14') then 2198 
			when(finance_status='financeStatus:15') then 2199 
			when(finance_status='financeStatus:16') then 2200
			else 2201 end ) finance_status,
			'0',create_time, _create_id from fx_db.finance_history where project_id = _project_id;			
	
		end if;
		
		set done=0;
		end loop;
	close rs_cursor;
	
END