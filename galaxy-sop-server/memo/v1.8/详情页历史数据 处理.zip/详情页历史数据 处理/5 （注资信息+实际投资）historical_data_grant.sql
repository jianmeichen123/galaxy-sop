CREATE DEFINER=`root`@`localhost` PROCEDURE `historical_data_grant`()
BEGIN
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE v_project_id bigint(20);
	declare i int default 1;
	-- 遍历数据结束标志
	declare done int default false;
	-- 游标
	declare cur cursor for 
	select  
	distinct a.`project_id` 
	from 
	( 
		select  project_id from fx_db.sop_grant_total a 
		where ( a.final_valuations is not null and a.final_valuations != '') 
		or (a.grant_money is not null and a.grant_money != '')
		or (a.final_share_ratio is not null and a.final_share_ratio != '')
		or (a.service_charge is not null and a.service_charge != '') 
		union all 
		select id as `project_id` from fx_db.sop_project a 
		where (a.final_valuations is not null and a.final_valuations != '')
		or (a.final_contribution is not null and a.final_contribution != '')
		or (a.final_share_ratio is not null and a.final_share_ratio != '')
		or (a.service_charge is not null and a.service_charge != '')
	) a 
	where a.`project_id` not in ( select distinct `project_id` from fx_db.information_result where title_id in (3012,3004,3010,3011) );
	-- 将结束标志绑定到游标
	declare continue handler for not found set done=true;
	declare continue handler for SQLEXCEPTION SET t_error=1;
	
	# 事物开始
	START TRANSACTION;
	
	## -------------------------------------------------- insert update delete start-------------------------------------------------##
	
	-- 打开游标
	open cur;
	-- 开始循环
	read_loop: loop
		-- 提取游标里的数据，这里只有一个，多个的话也一样；
		fetch cur into v_project_id;
		-- 声明结束的时候
		if done then
			leave read_loop;
		end if;
		-- begin : 业务逻辑 ---------------------------------------------------------------------
		
		-- 创建临时表
		drop table if exists fx_db.tmp_data;
		create temporary table if not exists tmp_data (
			`id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '',
			part_grant_id bigint(20) not null comment '',
			project_id bigint(20) not null comment '',
			title_id varchar(45) not null comment '',
			parent_id bigint(20) default null comment '',
			`code` varchar(20) not null comment '',
			field_1 varchar(100) default null comment '',
			field_2 varchar(100) default null comment '',
			field_3 varchar(100) default null comment '',
			field_4 varchar(100) default null comment '',
			field_5 varchar(100) default null comment '',
			is_valid int(11) default null comment '',
			created_time bigint(20) default null comment '',
			create_id bigint(20) default null comment '',
			updated_time bigint(20) default null comment '',
			update_id bigint(20) default null comment '',
			PRIMARY KEY (`id`)
		) DEFAULT CHARSET=utf8;
		
		#### 此处有个问题 ， 需要去掉STRICT_TRANS_TABLES ，不然报错 Truncated incorrect DECIMAL value: ''
		###  说是版本问题
		# select @@sql_mode;
		# set @@sql_mode="ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION";
		insert into fx_db.tmp_data (part_grant_id,project_id,title_id,parent_id,`code`,`field_1`,`field_2`,`field_3`,`field_4`,`field_5`,`is_valid`,`created_time`,`create_id`,`updated_time`,`update_id`)
		select 
			b.id,
			a.`project_id`,
			3022 as `title_id`,
			null as parent_id ,
			'grant-part' as code,
			b.`grant_name` as field_1,
			b.`grant_detail` as field_2,
			b.`grant_money` as field_3,
			b.`part_status` as field_4,
			b.`file_num` as field_5,
			0 as is_valid,
			b.`created_time`,
			b.`create_uid`,
			b.`updated_time`,
			null as update_id
		from `sop_grant_total` a
		right join sop_grant_part b on a.id = b.total_grant_id
		where `project_id` = v_project_id;
		
		-- select * from tmp_data;
		select count(*) into @total from tmp_data;
		
		if @total > 0 then 
			while i <= @total do 
				insert into fx_db.information_listdata (project_id,title_id,parent_id,`code`,`field_1`,`field_2`,`field_3`,`field_4`,`field_5`,`is_valid`,`created_time`,`create_id`,`updated_time`,`update_id`)
				select project_id,title_id,parent_id,`code`,`field_1`,`field_2`,`field_3`,`field_4`,`field_5`,`is_valid`,`created_time`,`create_id`,`updated_time`,`update_id` from fx_db.tmp_data where id = i;
				
				select last_insert_id() into @information_listdata_id;
				select  part_grant_id into @part_grant_id from fx_db.tmp_data where id = i;
				
				insert into fx_db.information_listdata (project_id,title_id,parent_id,`code`,`field_1`,`field_2`,`field_3`,`is_valid`,`created_time`,`create_id`,`updated_time`,`update_id`)
				select 
					a.`project_id`,
					3022 as `title_id`, 
					@information_listdata_id as parent_id,
					'grant-actual' as code,
					null as `field_1`,
					c.`actual_time` as field_2,
					c.`grant_money` as field_3,
					0 as `is_valid`,
					c.`created_time`,
					c.`create_uid`,
					c.`updated_time`,
					null as update_id
				from fx_db.sop_grant_total a 
				right join fx_db.sop_grant_part b on a.id = b.`total_grant_id`
				right join fx_db.sop_grant_actual c on b.id = c.`part_grant_id`
				where project_id = v_project_id and c.part_grant_id=@part_grant_id;

				set i = i+1;
			end while;
			set i = 1 ;
			set @total = 0 ;
		end if;   		
		-- end : 业务逻辑 ---------------------------------------------------------------------
		set done = 0;
	end loop;
	-- 关闭游标
	close cur;
	
	-- 实际注资不需要同步的 information_result.id
	insert into fx_db.historical_data_log (data_type, project_id)
	select '实际注资不需要同步',id from fx_db.information_result where title_id in (3012,3004,3010,3011) group by id;
	
	-- 如果tab页的实际注资中已录入信息，则将此信息同步到全息报告中
	insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`)
	select * from 
	( 
		select `project_id` as id,'3012', `final_valuations`, '0' from fx_db.sop_grant_total a where a.final_valuations is not null and a.final_valuations != ''
		union all 
		select `project_id` as id,'3004', `grant_money`, '0' from fx_db.sop_grant_total a where  a.grant_money is not null and a.grant_money != ''
		union all 
		select `project_id` as id,'3010', `final_share_ratio`, '0' from fx_db.sop_grant_total a where a.final_share_ratio is not null and a.final_share_ratio != ''
		union all 
		select `project_id` as id,'3011', `service_charge`, '0' from fx_db.sop_grant_total a where a.service_charge is not null and a.service_charge != ''
		-- 如果tab页没有实际注资的信息，则将详情页信息同步到全息报告中
		union all 
		select * from (
			select id,'3012', `final_valuations`, '0' from fx_db.sop_project a where a.final_valuations is not null and a.final_valuations != '' 
			union all 
			select id,'3004', `final_contribution`, '0' from fx_db.sop_project a where a.final_contribution is not null and a.final_contribution != '' 
			union all 
			select id,'3010', `final_share_ratio`, '0' from fx_db.sop_project a where a.final_share_ratio is not null and a.final_share_ratio != '' 
			union all 
			select id,'3011', `service_charge`, '0' from fx_db.sop_project a where  a.service_charge is not null and a.service_charge != '' 
		) a where a.id not in (select project_id from fx_db.sop_grant_total a where ( a.final_valuations is not null and a.final_valuations != '' ) or (a.grant_money is not null and a.grant_money != '') or (a.final_share_ratio is not null and a.final_share_ratio != '') or (a.service_charge is not null and a.service_charge != ''))
	) b where b.id not in(select distinct project_id from fx_db.information_result where title_id in (3012,3004,3010,3011))
	;
	
	## -------------------------------------------------- insert update delete end-------------------------------------------------##
	
	
	# 提交 or 回滚
	IF t_error = 1 THEN
		ROLLBACK;
	ELSE
		COMMIT;
	END IF;
	
	drop table if exists tmp_data;
	
	# 返回标识位的结果
	select t_error;   

END