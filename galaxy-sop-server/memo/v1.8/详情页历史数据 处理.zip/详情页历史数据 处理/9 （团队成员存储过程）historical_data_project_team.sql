CREATE PROCEDURE `fx_db`.`historical_data_project_team`()
BEGIN
	
#--------------------------------------
#------------处理团队成员----------------
#--------------------------------------

-- 需要定义接收游标数据的变量 
declare v_person_id,v_project_id,v_title_id,v_parent_id,v_create_id,v_created_time,v_update_id,v_updated_time bigint(20);
declare v_code varchar(30);
declare v_field_1,v_field_2,v_field_3,v_field_4,v_field_5 varchar(30);
-- 遍历数据结束标志
declare done int default false;
-- 游标
declare cur cursor for 
select 
	a.person_id,
	a.project_id,
	1303 as `title_id`,
	null as `parent_id`,
	'team-members' as code,
	b.`person_name` as field1,
	(case when(b.`person_duties` in ('CEO首席执行官','CE0','CEO','CEO,Chenhua201206','CEO/CTO','CEO，创始人','创始人&CEO','创始人，CEO','创始人，董事长兼CEO','创始人、CEO','创始人/CEO','创始人\CEO','代CEO','董事长&CEO','联合创始人 CEO','联合创始人，CEO','泥螺科技CEO（全职）'))  then 1352
	when(b.`person_duties` in ('COO首席运营官','COO','C0O','COO/CFO','联合创始人/COO','联合创始人，COO',' COO')) then 1353    
	when(b.`person_duties` in ('CFO首席财务官','CFO','cfo')) then 1354 
	when(b.`person_duties` in ('CIO首席信息官','CIO','clo')) then 1355
	when(b.`person_duties` in ('CTO首席技术官','CTO','CTO/CEO','董事长/CTO','联合创始人CTO','cto')) then 1356 
	when(b.`person_duties` in ('CDO首席数据官','首席数据官')) then 1357
	when(b.`person_duties` in ('CMO首席市场官','CMO')) then 1358
	when(b.`person_duties`='CBO首席商务官') then 1359 
	when(b.`person_duties`='GM总经理') then 1360
	when(b.`person_duties` in ('VP副总裁','VP','副总裁')) then 1361 
	when(b.`person_duties` in ('EC专家顾问','Expert Consultant专家顾问')) then 1362
	when(b.`person_duties` is null || b.`person_duties` = '暂无') then null
	else concat('1363_',person_duties) end) as field2,
	(case when(b.`person_sex`='1') then 1344
	when(b.`person_sex`='0') then 1343
	else null end) as field3,
	b.`person_telephone` as field4,
	(case when(b.`highest_degree` in ('1','大学肄业')) then 1372    
	when(b.`highest_degree` in ('2')) then 1373 
	when(b.`highest_degree` in ('3','本科')) then 1374
	when(b.`highest_degree` in ('4','硕士','在读硕士')) then 1375 
	when(b.`highest_degree` in ('5')) then 1376
	when(b.`highest_degree` in ('6','博士')) then 1377
	when(b.`highest_degree`='7') then 1378 
	else null end) as field5,
	c.`create_uid` as create_id,
	case when b.`created_time` is null or b.`created_time` ='' then c.`created_time` else b.`created_time` end as created_time,
	case when b.`updated_time` is null or b.`updated_time` ='' then null else c.`create_uid` end as update_id,
	b.`updated_time`
from fx_db.sop_project_person a 
left join fx_db.sop_person_pool b on a.`person_id`=b.id 
left join fx_db.sop_project c on a.`project_id`=c.id
where b.id is not null
and a.`project_id` not in (select distinct a.project_id from fx_db.information_listdata a where a.title_id = 1303 and code = 'team-members' )
#and a.project_id in (611,612)
;
-- 将结束标志绑定到游标
declare continue handler for not found set done=true;

set autocommit=0;

# 已经录入过的 , 写入log
#delete from fx_db.historical_data_log where data_type = '团队成员';
insert into fx_db.historical_data_log(`data_type`,`project_id`)
select '团队成员' as data_type,a.project_id 
from fx_db.sop_project_person a 
left join fx_db.sop_person_pool b on a.`person_id`=b.id 
where b.id is not null
and a.`project_id` in (select distinct a.project_id from fx_db.information_listdata a where a.title_id = 1303 and code = 'team-members' ) 
group by a.project_id;

-- 打开游标
open cur;
-- 开始循环
read_loop: loop
	-- 提取游标里的数据，这里只有一个，多个的话也一样；
	fetch cur into v_person_id,v_project_id,v_title_id,v_parent_id,v_code,v_field_1,v_field_2,v_field_3,v_field_4,v_field_5,v_create_id,v_created_time,v_update_id,v_updated_time;
	-- 声明结束的时候
	if done then
		leave read_loop;
	end if;
	-- begin : 业务逻辑 ---------------------------------------------------------------------
	
	-- step1 插入team-member主记录
	insert into fx_db.information_listdata(`project_id`,`title_id`,`parent_id`,`code`,`field_1`,field_2,field_3,field_4,field_5,create_id,created_time,update_id,updated_time)
	values(v_project_id,v_title_id,v_parent_id,v_code,v_field_1,v_field_2,v_field_3,v_field_4,v_field_5,v_create_id,v_created_time,v_update_id,v_updated_time);
	
	select LAST_INSERT_ID() into @parent_id;
		
	-- step2 插入team-member学习经历
	insert into fx_db.information_listdata(`project_id`,title_id,parent_id,code,field_1,field_2,field_3,field_4,field_5,create_id,created_time,update_id,updated_time)
	select 
		v_project_id,
		1303 as title_id,
		@parent_id,
		'study-experience' as code,
		a.begin_date as field_1,
		a.school as field_2,
		a.major as field_3,
		(case when(a.degree in ('高中')) then 2160    
		when(a.degree in ('大专')) then 2161 
		when(a.degree in ('学士','本科')) then 2162
		when(a.degree in ('硕士')) then 2163 
		when(a.degree in ('MBA')) then 2164
		when(a.degree in ('博士')) then 2165
		when(a.degree ='其他') then 2166 
		else null end) as field_4,
		a.over_date as field_5,
		v_create_id,
		case when a.`created_time` is null or a.`created_time`='' then null else v_created_time end as created_time,
		case when a.`updated_time` is null or a.`updated_time`='' then null else v_update_id end as update_id,
		a.`updated_time`
	from fx_db.sop_person_learning_experience a  
	where a.`person_id` = v_person_id;
	
	-- step3 插入team-member工作经历
	insert into fx_db.information_listdata(`project_id`,title_id,parent_id,code,field_1,field_2,field_3,field_4,field_5,create_id,created_time,update_id,updated_time)
	select 
		v_project_id,
		1303 as title_id,
		@parent_id,
		'work-experience' as code,
		begin_work as field_1,
		over_work as field_2,
		company_name as field_3,
		work_position as field_4,
		work_content as field_5,
		v_create_id,
		case when `created_time` is null or `created_time`='' then null else v_created_time end as created_time,
		case when `updated_time` is null or `updated_time`='' then null else v_update_id end as update_id,
		`updated_time`
	from fx_db.sop_person_work_experience   
	where `person_id` = v_person_id;
	
	-- end : 业务逻辑 ---------------------------------------------------------------------
	
	set done = 0;
end loop;
-- 关闭游标
close cur;
	
commit;
		
end