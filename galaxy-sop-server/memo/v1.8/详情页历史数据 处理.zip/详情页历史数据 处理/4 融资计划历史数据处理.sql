/*项目详情页 融资计划（融资金额、出让股份、项目估值）同步到全息报告中*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`) 


select id, '1943', `project_valuations`, '0', project_time, create_uid from fx_db.sop_project a where a.`id` not in ( select `project_id` from fx_db.information_result a where a.`title_id` in (1916,1917,1943) group by `project_id` ) and a.project_valuations is not null and a.project_valuations != ''

union all 

select id,'1916', `project_contribution`, '0', project_time, create_uid from fx_db.sop_project a where a.`id` not in ( select `project_id` from fx_db.information_result a where a.`title_id` in (1916,1917,1943) group by `project_id` ) and a.project_contribution is not null and a.project_contribution != ''

union all 

select id, '1917',`project_share_ratio`, '0', project_time, create_uid from fx_db.sop_project a where a.`id` not in ( select `project_id` from fx_db.information_result a where a.`title_id` in (1916,1917,1943) group by `project_id` ) and a.project_share_ratio is not null and a.project_share_ratio != ''


