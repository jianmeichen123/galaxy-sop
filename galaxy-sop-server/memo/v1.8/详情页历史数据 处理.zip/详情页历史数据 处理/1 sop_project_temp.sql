﻿#建表
CREATE TABLE `fx_db`.`sop_project_temp` (
  `id` BIGINT(20) NOT NULL,
  `project_describe` TEXT NULL COMMENT '业务简要概述及项目亮点',
  `project_describe_financing` TEXT NULL COMMENT '商业模式',
  `company_location` TEXT NULL COMMENT '公司定位',
  `user_portrait` TEXT NULL COMMENT '用户画像',
  `project_business_model` TEXT NULL COMMENT '产品服务',
  `operational_data` TEXT NULL COMMENT '运营数据',
  `industry_analysis` TEXT NULL COMMENT '行业分析',
  `prospect_analysis` TEXT NULL COMMENT '竞争分析',
  `next_financing_source` TEXT NULL COMMENT '下一轮融资路径',
  PRIMARY KEY (`id`));

#建表
CREATE TABLE `fx_db`.`sop_project_temp_old` (
  `id` BIGINT(20) NOT NULL,
  `project_describe` TEXT NULL COMMENT '业务简要概述及项目亮点',
  `project_describe_financing` TEXT NULL COMMENT '商业模式',
  `company_location` TEXT NULL COMMENT '公司定位',
  `user_portrait` TEXT NULL COMMENT '用户画像',
  `project_business_model` TEXT NULL COMMENT '产品服务',
  `operational_data` TEXT NULL COMMENT '运营数据',
  `industry_analysis` TEXT NULL COMMENT '行业分析',
  `prospect_analysis` TEXT NULL COMMENT '竞争分析',
  `next_financing_source` TEXT NULL COMMENT '下一轮融资路径',
  PRIMARY KEY (`id`));
  
  
#添加数据
insert into fx_db.sop_project_temp_old (id, project_describe, project_describe_financing, company_location, user_portrait, project_business_model, operational_data, industry_analysis, prospect_analysis, next_financing_source)
select id, project_describe, project_describe_financing, company_location, user_portrait, project_business_model, operational_data, industry_analysis, prospect_analysis, next_financing_source from fx_db.sop_project
where (project_describe is not null and project_describe != '')
or (project_describe_financing is not null and project_describe_financing != '')
or (company_location is not null and company_location != '')
or (user_portrait is not null and user_portrait != '')
or (project_business_model is not null and project_business_model != '')
or (operational_data is not null and operational_data != '')
or (industry_analysis is not null and industry_analysis != '')
or (prospect_analysis is not null and prospect_analysis != '')
or (next_financing_source is not null and next_financing_source != '');


#查询旧表数据手动转换插入新表（sop_project_temp）
select *  FROM fx_db.sop_project_temp_old limit 0, 1000;
select *  FROM fx_db.sop_project_temp_old where id not in (2586,2799,2806,2811)  limit 1000, 996;
select *  FROM fx_db.sop_project_temp_old limit 2000, 1000;
select *  FROM fx_db.sop_project_temp_old limit 3000, 1000;
select *  FROM fx_db.sop_project_temp_old limit 4000, 1000;



CREATE TABLE `fx_db`.`historical_data_log` (
  `data_type` VARCHAR(100) NULL,
  `project_id` VARCHAR(100) NULL);
