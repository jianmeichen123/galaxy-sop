/*将项目详情页中的‘业务简要概述及项目亮点’ 同步到 全息报告中的‘2.2.2 该项目的三个核心亮点’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1208 AS 'title_id', a.project_describe AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.project_describe IS NOT NULL AND a.project_describe != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1208);

/*将项目详情页中的‘商业模式’ 同步到 全息报告中的‘商业模式’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1203 AS 'title_id', a.project_describe_financing AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.project_describe_financing IS NOT NULL AND a.project_describe_financing != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1203);

/*将项目详情页中的‘公司定位’ 同步到 评测报告中的‘项目定位’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1253 AS 'title_id', a.company_location AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.company_location IS NOT NULL AND a.company_location != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1253);

/*将项目详情页中的‘用户画像’ 同步到 全息报告中的‘2.5.5 该细分市场的用户画像’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1223 AS 'title_id', a.user_portrait AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.user_portrait IS NOT NULL AND a.user_portrait != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1223);

/*将项目详情页中的‘产品服务’ 同步到 全息报告中的‘2.5.4 切入的垂直细分市场’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1222 AS 'title_id', a.project_business_model AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.project_business_model IS NOT NULL AND a.project_business_model != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1222);

/*将项目详情页中的‘运营数据’ 同步到 全息报告中的‘4.1.1 项目关键运营数据’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1403 AS 'title_id', a.operational_data AS `content_describe1`, 0 AS `is_valid` ,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.operational_data IS NOT NULL AND a.operational_data != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1403);

/*将项目详情页中的‘行业分析’ 同步到 全息报告中的‘5.5.1 该项目所在行业的发展趋势，可能的替代技术’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1541 AS 'title_id', a.industry_analysis AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.industry_analysis IS NOT NULL AND a.industry_analysis != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1541);

/*将项目详情页中的‘竞争分析’ 同步到 全息报告中的‘5.1.1 前三项核心竞争力’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1504 AS 'title_id', a.prospect_analysis AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.prospect_analysis IS NOT NULL AND a.prospect_analysis != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1504);

/*将项目详情页中的‘下一轮融资路径’ 同步到 全息报告中的‘9.3.1 下一轮融资的必要条件’*/
INSERT INTO fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
SELECT a.id, 1927 AS 'title_id', a.next_financing_source AS `content_describe1`, 0 AS `is_valid`,b.project_time, b.create_uid FROM fx_db.sop_project_temp a 
LEFT JOIN fx_db.sop_project b ON a.id = b.id 
WHERE a.next_financing_source IS NOT NULL AND a.next_financing_source != '' 
AND a.`id` NOT IN (SELECT `project_id` FROM fx_db.information_result WHERE `title_id`=1927);






