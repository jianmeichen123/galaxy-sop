/*将项目详情页中的‘业务简要概述及项目亮点’ 同步到 全息报告中的‘2.2.2 该项目的三个核心亮点’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1208 as 'title_id', a.project_describe as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.project_describe is not null and a.project_describe != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1208);

/*将项目详情页中的‘商业模式’ 同步到 全息报告中的‘商业模式’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1203 as 'title_id', a.project_describe_financing as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.project_describe_financing is not null and a.project_describe_financing != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1203);

/*将项目详情页中的‘公司定位’ 同步到 评测报告中的‘项目定位’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1253 as 'title_id', a.company_location as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.company_location is not null and a.company_location != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1253);

/*将项目详情页中的‘用户画像’ 同步到 全息报告中的‘2.5.5 该细分市场的用户画像’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1223 as 'title_id', a.user_portrait as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.user_portrait is not null and a.user_portrait != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1223);

/*将项目详情页中的‘产品服务’ 同步到 全息报告中的‘2.5.4 切入的垂直细分市场’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1222 as 'title_id', a.project_business_model as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.project_business_model is not null and a.project_business_model != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1222);

/*将项目详情页中的‘运营数据’ 同步到 全息报告中的‘4.1.1 项目关键运营数据’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1403 as 'title_id', a.operational_data as `content_describe1`, 0 as `is_valid` ,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.operational_data is not null and a.operational_data != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1403);

/*将项目详情页中的‘行业分析’ 同步到 全息报告中的‘5.5.1 该项目所在行业的发展趋势，可能的替代技术’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1541 as 'title_id', a.industry_analysis as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.industry_analysis is not null and a.industry_analysis != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1541);

/*将项目详情页中的‘竞争分析’ 同步到 全息报告中的‘5.1.1 前三项核心竞争力’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1504 as 'title_id', a.prospect_analysis as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.prospect_analysis is not null and a.prospect_analysis != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1504);

/*将项目详情页中的‘下一轮融资路径’ 同步到 全息报告中的‘9.3.1 下一轮融资的必要条件’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`project_time`,`create_uid`)
select a.id, 1927 as 'title_id', a.next_financing_source as `content_describe1`, 0 as `is_valid`,b.project_time, b.create_uid from fx_db.sop_project_temp a 
left join fx_db.sop_project b on a.id = b.id 
where a.next_financing_source is not null and a.next_financing_source != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1927);






