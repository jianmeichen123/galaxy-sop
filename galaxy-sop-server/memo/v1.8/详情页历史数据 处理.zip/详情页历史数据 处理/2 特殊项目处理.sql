/* -- Query: select *  FROM fx_db.sop_project_temp where id in (2586,2799,2806,2811) -- Date: 2017-09-14 17:02 */ INSERT INTO `sop_project_temp` (`id`,`project_describe`,`project_describe_financing`,`company_location`,`user_portrait`,`project_business_model`,`operational_data`,`industry_analysis`,`prospect_analysis`,`next_financing_source`) VALUES (2586,'
专业的（香港）汤品专营店
','专业的（香港）汤品专营店','
综合产品
地点：妇产医院人群：孕妇/产妇
功能：营养／补血／补气／产后恢复／催奶 材料产品：鱼汤／猪蹄汤／鸡汤／骨汤／菌汤，等 半成品/炖汤伴侣
','
白领女性群体，月子期，住院等为主要客户群体
','日订单量200单左右，客单价：45元，提供汤品堂食+外卖服务','月交易额：50万左右，客单价：45元','
随着人们生活水平的提高，现代人们对健康愈发重视，养生逐渐为数量庞大的人群所推崇。据调查，在地方书店和当当网等各大网络书店，药养生类书籍已连续数年蝉联销售榜单冠军；而淘宝购买养生汤料包的人群也处于高速增长中，——养生行业得到了空前的发展。在近千亿的市场背景下，和互联网+的时代，全国还没有一家实体店加互联网+（o2o）的养生汤连锁品牌。虽为创新理念，但汤补产品历来拥有广泛的受众基础，因此无需大做市场培育工作，就已拥有天然顾客群，尤其二胎政策刺激对于行业又是一大利好，市场之大超乎想象。各地养生汤行业现分布在酒店、养生会馆、实体养生汤馆等传统实体店，其品质也参差不齐，营销模式也较为传统。在这种状况下需要行业内出现具备一定的品牌基础和创新理念的领军品牌。
在南方人们是注重喝汤的，尤其是在香港，煲汤更是家家户户每一天的必须食用美食。香港人最爱喝老火汤，每餐无汤不欢。有统计发现香港人的平均寿命居全球第二名，有人就将其归功于“老火汤”。可见，一煲细火慢熬而成的老火汤在香港人心中占有非常重要的地位。在香港，煲汤也是每个女人的必备功课，香港人擅用煲汤方法达到进补目的，日常起居中常见的食材都可以被主妇们拿来当做煲汤的食材，同时着重添加几味相应的功能性食材
','
万记汤品品牌起源： 
源于香港的万记汤品，秉承中华千年的“药补不如食补，食补不如汤补”的养生理念，由阿婆家世代传承，选取中华民族源远流长的食补良方，为快节奏的现代人提供最营养、最便捷、高品质的食疗滋补汤品。最具功能性的、滋补性的汤品，离不开珍贵的食材，为了确保食材的品质和功效，萬記湯品在食材选择上严格要求，不遗余力。根据阿婆汤对品质和功能性的标准，所有珍贵食材——花胶、燕窝、虫草花等等，均从香港精心选择、采购，并由香港空运至青岛，从源头上保障食材品质。 青岛万记尚品餐饮管理有限公司是香港总部直属的全资公司，负责中国大陆“万记汤品”的开设和加盟招商，公司采用区域招商的形式展开，市场运作具体为实体店加互联网+（o2o）的方式，青岛公司总部负责全国“万记汤品”品牌招商。
',NULL); INSERT INTO `sop_project_temp` (`id`,`project_describe`,`project_describe_financing`,`company_location`,`user_portrait`,`project_business_model`,`operational_data`,`industry_analysis`,`prospect_analysis`,`next_financing_source`) VALUES (2799,'
“M\'CAKE”是法国百年品牌“马克西姆”为全球美食者打造的专属蛋糕品牌，目前服务上海、杭州、苏州三大城市，自主研发了24款主打蛋糕，尤其是Mcake的4096层的拿破仑酥皮系列蛋糕，颇受消费者喜爱。
','时尚定位的烘焙店  （原麦山丘做线下店，m cake做线上）','
年轻，有消费力女性
','
年轻白领，有消费力。讲究生活品质群体。
','
Napoléonauxmyrtilles蓝莓轻乳拿破仑
Myrtillesfraiches,bio,feuilletageaugoûtdebeurrefrais,marmeladedemyrtilles,crèmechantilly,ettoutcelàdansleplaisirdupalais.
精选野生蓝莓的清爽可口/芝士的香浓/优质奶油的醇厚。
起酥皮的香脆可口/内层轻乳芝士的松软
层层美味/回味无穷
MCAKEGâteau de la Lune multicolore缤纷悦缘

Les quatre couleurs pour cette Fête de la Lune. Des yeux à la bouche, ces gâteaux de la lune multicolores vous permettent de célébrer la fête traditionnelle chinoise avec votre amour accompagné d’un gôut magnifique.
四色的缤纷，在中秋时节让鲜亮的色彩给自己一点由视觉到味觉的不同滋味，和你爱的人一起享受这温馨节日，这个中秋，别样的滋味。
MCAKERosetteCoeur心玫罗赛特

profondeDécoréeavecdespétalesderoses,unamour
　　immortelCetteSaint-Valentinchinoise,unefêteamoureuse
　　RosetteCoeur,uncadeauréservéàvous
　　点缀其上的玫瑰鲜瓣，就此演绎一段跨越银河的爱恋
　　这个七夕，让我们在一起
　　心玫罗赛特，七夕爱的专.属定.制
MCAKEL’amouraveclamyrtille蓝莓星缘

Commeuncoupdefoudre,unerencontreextraordinaire
Lefromageblanccrémeuxfusionneladouceureduchocolatblanc,plusdesmyrtillescommelesétoilesducieletuncoulantavecdesmyrtillesfraîches.
醇厚奶油芝士与白巧克力的绵柔诱惑，加上点点闪耀星光的蓝莓和熔心果酱
也会在切开一瞬，果酱熔岩融入芝士皓月，撞击搭载着沙布蕾的松脆
MCAKEFromageVelouté香溢新芝

Ladécorationn’estplusindispensable.
Uneémulsiondelacrèmecheese,mixéd’unecouchedelacrèmefouettée.
Unesaveurharmonieuseetpénétrante.
传,承享受纯粹，修饰不再重要
只融在口的芝香，让舌尖主宰你的私享
蓬松夹着鲜香淡雅，因齿间的温度而融化肆溢
奶香轻盈，用层层的绵柔瞬间勾勒永恒的味觉记忆
MCAKENapoléonvanille经典香草拿破仑

Avecunstyletypiquementfrançais,cegâteauuniquevouslaisseradessouvenirsNapoléoniens.
纯正的法国风味/香浓绵甜的吉士酱
加上香脆起酥皮
入口即化/层层美味
MCAKEDiablechocolat魔鬼巧克力

LeDiableartistevousamèneversl\'enferduchocolatnoir,vousexitelessensparsoncroquantetsoncroutillantdebiscuit.
MCAKE/将艺术气质渗入蛋糕制作环节/
每一款作品表层/都被赋予千变万化的笔触/
当你收到的时候/绝不需要担心“撞衫”的危险
MCAKEPinkRosettePink·罗赛特

Unecrèmelégèreauchocolatblancparfuméeàlarose,litchisfraiscoupésencubes,unefinegeléedeframboise
细腻软甜的玫瑰白巧克力慕斯邂逅酸爽的树莓啫喱于珍馐荔枝
色与味的双重盛宴
MCAKESabléparfait沙布蕾芭菲

Unerecettetradionnellefrançaise,avecunemousseàlavanilledeMadagascaretuncoulisauchocolatquifonddirectementdanslabouche,leParfaitàlavanillevousdonneraitlefraicheurenpleinété.
法式传统沙布蕾饼，搭配马达加斯加香草芭菲和熔岩巧克力，入口即化，尽享夏季沁脾清凉。
MCAKEVelourrouge蔓越莓红丝绒

Danslacouleurdelapaixetlaconfusion,lacannebergedehautequalitéhonoreleparfumaristrocratiquedel\'histoire.
MCAKE/
完美的复苏红丝绒蛋糕的传统和历史/
并选用新鲜蔓越莓点缀其上/
让贵族般的色香/再度氤氲美妙的午后
MCAKEGâteaudesanges天使巧克力

D\'ungoûtdeplusde100ans,ungâteaufrabriquéd\'unefaçonminutieusevousrappellel\'inoccupationetleromantismeparisiens.
MCAKE/
用巴黎的慵懒与浪漫/与马克西姆传,承的百年味道/
精心制作出让天使都会爱上的美丽
MCAKENapoléonauxfraises拿破仑莓恋

Fraisesfraîchesetsucrées,croustillantdufeuilletage,moelleuxdelagenoise,voilàungâteauquel’onnepeutpasnecommander.
新鲜草莓的清爽甜美/优质奶油的醇滑
起酥皮的香脆可口/内层轻乳芝士的松软
层层美味/惊喜不断
MCAKEManguechantilly芒果·Mangue

Lameilleurequalitéedemanguequel\'onpuissetrouver
L‘additondemangueetdefruitdelapassionpourunesaveurparfaite
Unparfumquinepourraqueexaltervospapilles
用心甄选热带优质芒果/芒果及百香果的完美组合/
香气迷人，绽放清甜芳华
MCAKESoiréeBailay’s百利派对

Unmomentmerveilleuxentrelesamis,lesamoureuxetlessoirées
MélangelacrèmeetBailay’s,rajoutéuncoutfineduchocolatblancduBruxelle
Partagéunedégustationconvivialeetfantastique
来一场百利私享派对
奶油和威士忌的美妙融合，再加一点比利时白巧克力
感受着丝般顺滑的口感，分享与闺蜜专属的时间
MCAKELeThé摩登茶道

Unepromenadeàlacampagnedanslesbambous.
Douxcouchesdebiscuitsmoelleuxauchocolat,deuxcouchesdemousseaumatchaduJapon,cegâteauauthévous
donneunsaveurextraodinairequireprésentelaphilosophieorientale.
在巴黎的街头回到自然的茶意翠语，
时尚与原生态微妙平衡，正如比利时白巧克力与顶级抹茶间的味觉语言
冲突，彼此的分明；融合，彼此的丰满。停下，聆听。
MCAKEGâteaudecrêpes法香奶油可丽

Unegenoiselégère,descrêpesfondantes,ungoûtsubtiledecrèmedefromage,etunedominationd’amandestorrifiées.
奶油绵甜柔软、香郁醇滑/轻乳芝士蛋糕松软可口/
弹性十足的可丽饼/细腻浓郁的芝士酱/以及松脆的杏仁片/
口感层次极为丰富
MCAKELeSoleil阳光心芒

Unaprès-midisouslesoleil,unetassedethé,ungâteaudemousseàlamangue.
Deuxcouchesdebiscuitsgénoisenature,deuxcouchesdemousseàlamangue,unefinecouchedegeléemangue.
阳光下的心情，世界会很美
呼吸着芒果清香醉人的果芳
入口清甜的法国荔枝酒会让天际也染上了色彩
只一口，阳光早已开启心情空间
MCAKEDacquoiseauxnoix胡桃布拉吉

Unstylededacquoise,uncroquantdenoixetunfondantdecrèmeaubeurre.
浓郁布拉吉风味/
口感细腻入口即化/
每一颗核桃仁都香脆有嚼劲
MCAKELotusNoir巧克力黑兰

Cognac,unspititueuxprovenantderaisin.
FusionéauxchocolatnoirduBruxelle.
Ungoutinoubliableetenrichissant.
这是法国白兰地的一次重生
以另一种脱胎换骨的形式，加上比利时黑巧克力的爽滑
借着时间的指针，在舌尖，在心间，画出微醺的轨迹
MCAKEMoussedethévert蒸青抹茶

Siropderose,biscuitscuillères,thévert,fermezlesyeuxetenvolez-vouscommeunefeuilledethéauventversParis.
用自然的抹茶清香/搭配口感上乘的提拉米苏/
合成美妙的回甘滋味/
降落到巴黎的城郊/完成一次浪漫的田园幻想
MCAKEOpéra魅影歌剧院

Cegâteautrèspopulairedanslesannées60duderniersiècleàParis,àcejourl\'Opéraestunepâtisseriequel\'ontrou
vecheztouslesgrandspâtissiers
MCAKE/将上世纪60年代风,靡巴黎的歌剧院蛋糕/完美复制到今天的生活之中/7层甜美口感/宛如华丽舞台般层层绽放/如果细细品味/甚至可以感觉到黑巧克力在其中的魅惑/或许人生如戏/但巴黎的味道永远都在
MCAKERicotta瑞可塔厚爱

Aveclalégéretéetleparfumdecegâteau,ilvouslaisseradessouvenirsenbouchetrèslongtemps.
MCAKE/
法国独特芝士酱/简单而不平凡/
这一刻/只有享受
MCAKEGenoisecafé卡法香缇

Traditioneletunique,l\'amertumeducaféetdelacrèmevousconduisentdansunrêvederomantismeetd\'amour.
MCAKE/
传,承独特技艺的奶油咖啡香缇蛋糕/融入更多浪漫味道/
等待你用心揭开
','
M cake
管理团队：
原麦山丘：30人 （15%财务）  单店标准：18人-20人
Mcake：   高洁 总经理  

“M\'CAKE”是法国百年品牌“马克西姆”为全球美食者打造的专属蛋糕品牌，目前服务上海、杭州、苏州三大城市，自主研发了24款主打蛋糕，尤其是Mcake的4096层的拿破仑酥皮系列蛋糕，颇受消费者喜爱。
2012年上海；
融资：2013年创新工场：pos 1.3亿  2600w 人民币   上线4个月；
数据：2016年   1.8亿 收入       净利润：上半年 规模，下半年利润  9月开始盈利    2016年：-1600万
城市：上海，北京，杭州，苏州
营业方向：线上业务
线下：工厂：自营   
           物流：自有 100配送员     第三方：安鲜达 （易果）最大的生鲜电商； 顺丰的顺冷，快牛；  成本：20元/单   郊环以内；
日订单量：2000单   客单价：270元    2帮  （包含物流）     （成本结构：毛利率：60%   食材：15%，人工+制造费：15%）
产品+品牌+渠道  
产品差异化是前提
收入比例：线下 地推  50%；线上：50%
Mcake  融资额： 
创始人：姚总，叶总，张总    700万    后叶总借款：300万       叶总：65%   张总：17.5%；姚总：17.5%
2012年1月：天使：雷军个人 （顺为GP）， 口袋购物，jason（李井，叶树红）   500万  16%   
A轮：2013年创新工场   2600万  pos  3亿

','
根据烘焙行业发展状况，为了发现市场营销机会，更好地满足消费者的需求，我们烘焙蛋糕店需要确定一下细分变量：地理细分、人口细分、心理细分、行为细分。
　　1、地理细分：
　　首先，蛋糕店位于电子科技大学东区外，以学校师生及教职工家属为主要消费市场。其次，附近的居民也是消费市场之一。
　　2、人口细分：
　　一方面，学校学生人口数量大，年龄主要集中在18—26岁，生活经济来源主要来自父母提供，有小部分同学通过兼职赚取额外的零花钱，但是赚得也不多，总的来说，消费不起太贵的烘焙产品。另一方面，附近居民以普通居民为主，大多数人不会消费价格比较昂贵的烘焙糕点。
　　3、心理细分：
　　一方面，首先，大学生思想新潮，比较容易接受新鲜事物，也乐于尝试。其次，学习之余，需要有一个空闲的时间来放松、缓解压力。再次，大学正值恋爱的年龄，学校情侣众多，需要营造浪漫的好去处。另一方面，附近的居民也有儿童群体，周末需要与父母放松，共度天伦之乐的好去处。
　　二、目标市场选择
　　根据市场细分，确定以下四类人群为我们的目标市场：
　　1、企事业上班族：
　　据调查上班族主要以速食作为解决日常三餐的方式，而在早餐方面，面包是他们必不可少的速食品，并且上班族有比较稳定的工资，商品价格的变动，对他们需求弹性较低，因此，上班族这部分消费群体可作为本烘焙蛋糕店的固定消费者。此消费群体由于工作的压力较大，，需要有一个空闲的时间缓解自己的压力，就这一情况我们可推出特色服务DIY蛋糕制作。
　　2、高校的在校学生：
　　在校大学生思想新潮，比较容易接受新的东西，同时大学的高等教育让学生对新生事物的理解异于其他群体。并且，减肥是我们大学生一直追求的，所以我们将推出的有机蔬菜蛋糕这一新鲜口味是非常符合我们当代大学生需求。
　　3、喜爱浪漫的小情侣：
　　情侣必定逃不开浪漫一说，心意成为赢取女孩芳心的主要筹码。所以在一些节日里男孩们送什么样的礼物给女朋友成了他们头疼的事。这就是一大潜在需求，所以我们除了DIY蛋糕，本蛋糕店还推出 DIY 巧克力和DIY饼干，可作为一些小情侣在一些节日里制作来当作礼物相赠。
　　4、80 后、70 后妈妈：
　　如今的家长是孩子为宝，简单的玩具已经不能满足孩子玩耍的需求，因此，DIY蛋糕制作也为孩子家人提供了一个游玩的场所。一些与众不同的口味，
　　三、目标市场的SWOT分析
　　（1）优势（Strengths）：本烘焙蛋糕店位于学校附近，主要的目标客户是学生，他们是市场上大量的潜在需求，这是选择学生这一目标市场的首要条件，并且在价格上我们会经过调查了解他们的经济条件，主要定位在低档这一价位。而且我们的主打品牌是健康的有机蔬菜蛋糕，对顾客的健康有力，且遵循顾客就是上帝的原则，我们有良好的服务态度，高质量、低价格的烘焙商品，且有较高的优惠服务，相信能招来不少的喜爱蛋糕类食品的消费者。
　　（2）劣势（Weakness）：但是也正因为本烘焙蛋糕店没有基础的顾客群，且店小，人少，宣传的范围不够广，效果不会有计划那么好。且开店推出的有机蔬菜蛋糕，DIY蛋糕制作初期所要花费的成本大，短时间内不能收回成本的话会导致店无法经营下去。
　　（3）机会（Opportunities）：蔬菜蛋糕源于日本，它以毛豆、胡萝卜、西红柿、玉是米等蔬菜或其它农产品为主要原料，经过调味制作而成，口感清爽，不甜腻。2008年，蔬菜蛋糕开始传入我国市场，在上海、广东等地这种新型蛋糕很快得到消费者认可，尤其受到那些想保持好身材的女孩们的青睐。
　　（4）威胁（Threats）：但是由于有机蔬菜蛋糕未被燕郊地区的消费者所熟知，有可能短时间内顾客流量低，且周围的几家烘焙蛋糕店有很大的竞争力，顾客很难改变一贯的口味。并且DIY蛋糕、DIY巧克力、DIY饼干制作只是在一些节日里，有人过生日时顾客才会购买，不像面包在一定时间内频繁购买。所以这项经济收入来源不够稳定。如果在面包方面没有创新出各式花样来满足顾客的个性需求，本烘焙蛋糕店也受到一定的威胁难以经营。
　　四、市场定位
　　1、产品定位：
　　本烘焙蛋糕店生产多种类型的蛋糕、面包、西点，主打有机蔬菜蛋糕，有机蔬菜蛋糕店更加突出的符合现代人需求的健康的饮食理念。有机蔬菜蛋糕是以有机蔬菜为主要原材料，经过调味更加适合现在人对食物的需求。玉米、胡萝卜、地瓜、毛豆等健康的有机蔬菜都可以作为其原材料，而且口感爽而不甜腻，不仅健康养生，连怕胖爱美的女性都可以大胆放心享用。
　　由于主要的消费群是大学生，针对大学生早餐的消费需求，我们除了推出早餐面包和糕点之外，还为消费者提供种类繁多的面包和西点供效用；产品都是适量当天制作当天销售，对于剩余产品也做好绝对保鲜工作绝对保证质量。
　　2、价格定位：
　　每款不同的蛋糕价格不同，但是都会比市场上同等类型的蛋糕相比只低不高，以符合学生的消费水平，在保证收回自己成本的基础上给与顾客满意的易接受的价格。主要定为低档价位，针对上班族的，经济收入较高的，不在乎价格只追求生活品质的这类群体，生产出中档价位的烘焙产品供消费者购买。顾客的付款方式可以用现金和信用卡两种方式支付。
　　3、服务定位：
　　除了对人员及服务个方面的严格要求外，本烘焙蛋糕店针对目前的市场需求，首先，主要推出蛋糕DIY服务，因为当前消费者对个性化服务的要求的不断提高，所以针对顾客自己做的，干净，温馨的消费心理分析，及她们希望以一种休闲的方式度过一段愉快的时间，或者是以自己的亲手所做的蛋糕表示对朋友的祝福。这既满足青年一族对时尚潮流的追求，也满足他们对美食文化的热爱。，特别是该市场的消费者讲究新颖、自然、甜蜜，DIY 巧克力多为情侣一起做，来庆祝特别的日子。其次，消费趋势的网络化，加强网络经营，制作特色网页及完善的网页宣传即网络的服务管理，提供保质保速地服务。
　　4、店面形象定位：
　　蛋糕店主要让人体现温馨感觉装修无须奢华，但对整洁、干净程度的要求较高。店主要分为前厅和厨房两部分，前厅用于接待顾客定做蛋糕及DIY蛋糕制作的预约和销售面包、西点等，前厅应分顾客接待区和糕点销售区两个部分，形成井然有序的店面环境给顾客一种轻松销售氛围。厨房用于制作蛋糕和准备材料。从装修上看，以淡黄、粉红和淡紫色为主，材质以蕾丝为主，满屋挂满钻的挂饰，以小女生的喜好为目标，营造一种温馨的感觉。店内粘贴有顾客制作过程的照片、蛋糕的照片等，起到了很好的宣传效果。
　　5、促销竞争定位：
　　店内烘焙商品定期都会有打折优惠，每次不同种类的蛋糕，不仅限于一种，让顾客可以有机会品尝店内每种蛋糕。另外，在节日期间还另有优惠，有买大蛋糕送小面包的惊喜。顾客还可以办理优惠积分卡，就可以一直享受优惠了。本烘焙蛋糕店还采取特别的送礼品策略，即凡是来本店购买满二十元或五十元者可以获得不同种类的小饰品一件，且对于买生日蛋糕的还会送生日礼物一件。
','

产品+品牌+渠道   构建未来的竞争力。好产品+品牌溢价
竞争对手：木屐。。。。
巴黎贝甜：10亿   亏损  韩国面包店在国内亏损   管理效率上不来，人才留不住  大陆：
多乐之日：100店
85度c：净利润：10亿  在台湾股票市场表现非常好
桃李：走商超渠道；（ 2016年进入一线城市，过往在二三线城市   ）

烘焙是个独立的行业，行业分散，没有巨头，在资本市场没有什么成功案例，A股票市场：元祖，桃李，还一个新疆
境外：克里斯汀 在香港上市，85度c 在台湾上市，面包新语：新加坡上市
对餐饮和市场或者烘焙市场的未来看法：
烘焙行业类似快消品：服务轻，与用户接触点短，如果找到好的接触方式，容易复制，比较好享受品牌红利
餐饮：选址，管理水平，器皿，服务，餐饮比较容易梳理品牌，体验丰富，无法复制。难享受品牌红利。餐饮连锁未来未必是个好生意。
餐饮外卖：从生意角度上来讲，不成立，用户付费水平太低。商家不盈利。但是对用户，硬需求。成立的业态，成本结构改变 / 提高消费 。
在特定的场景是
',NULL); INSERT INTO `sop_project_temp` (`id`,`project_describe`,`project_describe_financing`,`company_location`,`user_portrait`,`project_business_model`,`operational_data`,`industry_analysis`,`prospect_analysis`,`next_financing_source`) VALUES (2806,'
馋肉了是一个优质原产地肉类垂直电商平台，用户可以在馋肉了上直接购买肉类产品。
',NULL,NULL,NULL,'
馋肉了
​          
圣纯精品羊元宝（500g）￥68.9
圣纯有机羊蝎子（1000g）             RMB 68    
圣纯有机汤骨（1000g）             RMB 42    
圣纯有机羔羊寸排（500g）             RMB 58    
圣纯有机羊腰（500g）             RMB 89        
圣纯有机羔羊元宝肉（500g）             RMB 89    
圣纯有机羔羊腿肉卷（500g）             RMB 69    
圣纯有机羔羊肉串（500g）             RMB 69     
羊蝎子火锅礼盒(预售)             RMB 198     
',NULL,NULL,'
冻品在线，美菜，链农，天平派
',NULL); INSERT INTO `sop_project_temp` (`id`,`project_describe`,`project_describe_financing`,`company_location`,`user_portrait`,`project_business_model`,`operational_data`,`industry_analysis`,`prospect_analysis`,`next_financing_source`) VALUES (2811,'
　\"\"
　　如今，谁再提O2O，估计投资人直接就挂掉电话了。喊了这么多年的“线上+线下”，人们最后发现，除了烧钱，最后什么也没有。随着餐饮平台被曝出监管漏洞，传统餐饮业开始把目光回归到更重的线下。
　GO串，将互联网思维彻彻底底的运营到自己整个流程的各个环节，实现了O2O的新玩法。
　　\"\"
　　食品加工厂的产品既可以供应木屋烧烤的实体店，也可以在网上商城售卖，还可以根据用户所下订单，直接送到用户的消费场景，比如家庭聚餐或室外活动。
　　以往上门服务的O2O，比如洗车、美甲等等，由于每单的成本太大，最终都走不长远。这给上门O2O敲响了警钟：如何降低每一单的成本?又摆脱单一的补贴模式?
　　脉度良子，一家上门服务的按摩品牌。在线下，通过开社区店，来完成线上和线下的衔接。同样，GO串也在线下铺社区店，来进行覆盖。不过，据其创始人王乐武介绍，GO串的社区店，更多的是扮演仓储的角色，真正完成上门的还是他们的神器——擎小柱。擎小柱，实际上就是一辆流动烧烤车，待用户在微信上下单后，擎小柱就可以及时上门服务。
　　在其公司进行采访时，GO串创始人王乐武正在指挥人们将马上交货的10台擎小柱进行整理。炫彩的车身，明亮的无烟烟囱，十余辆擎小柱排成一排，十分炫酷。王乐武告诉开店帮记者，这些擎小柱都是经过改装，采用了无烟鲜风系统和纯天然气烤炉，炫酷又环保。由于可以随时流动，这台烧烤车可以出现在小区或

',NULL,NULL,NULL,'
。GO串在北京燕郊拥有15亩地的生产加工物流配送中心，并获得国家食品安全QS认证，其移动烧烤车装有车载净化系统，获得的流动贩卖牌照也避免了地摊天天和城管打交道的问题。而在顾客最关心的食品来源方面，通过O2O的形式，GO串所有销售都是通过微信支付，每个烧烤车每天备货量，销售量均有数据统计，烧烤车主是不是进了私货很容易被发现。同时，统计数据可以对每辆烧烤车的销售进行实时监控，并核定出每辆车的平均销售水平，避免了收现金的情况。

','
北京8个社区店，如销售量：1000串左右
',NULL,NULL,NULL);