﻿insert into fx_db.information_result(`project_id`,`title_id`,`content_choose`,`is_valid`,`created_time`,`create_id`) 
select id, '1108', 
(case when(finance_status='financeStatus:0')  then '尚未获投'
	when(finance_status='financeStatus:1') then 1122    
	when(finance_status='financeStatus:2') then 1123 
	when(finance_status='financeStatus:3') then 1124
	when(finance_status='financeStatus:4') then 1125 
	when(finance_status='financeStatus:5') then 1125
	when(finance_status='financeStatus:6') then 1125
	when(finance_status='financeStatus:7') then 1126 
	when(finance_status='financeStatus:8') then 1126
	when(finance_status='financeStatus:9') then 1127 
	when(finance_status='financeStatus:10') then 1128
	when(finance_status='financeStatus:11') then 1128
	when(finance_status='financeStatus:12') then 1128 
	when(finance_status='financeStatus:13') then 1129 
	when(finance_status='financeStatus:14') then 1130 
	when(finance_status='financeStatus:15') then 1139 
	when(finance_status='financeStatus:16') then 1140
	else '不明确' end ) finance_status, 
'0',`project_time`,`create_uid` from fx_db.sop_project a where a.`id` not in ( select `project_id` from fx_db.information_result a where a.`title_id` = 1108)