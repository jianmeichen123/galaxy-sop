/*将项目详情页中的‘公司名称、法人、成立时间’ 同步到 全息报告中的‘公司名称、法人、成立时间’*/
insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
select a.id, 1814 as 'title_id', a.project_company as `content_describe1`, 0 as `is_valid`, project_time, create_uid from fx_db.sop_project a 
where a.project_company is not null and a.project_company != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1814);

insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
select a.id, 1815 as 'title_id', a.company_legal as `content_describe1`, 0 as `is_valid`, project_time, create_uid from fx_db.sop_project a 
where a.company_legal is not null and a.company_legal != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1815);

insert into fx_db.information_result(`project_id`,`title_id`,`content_describe1`,`is_valid`,`created_time`,`create_id`)
select a.id, 1816 as 'title_id', a.formation_date as `content_describe1`, 0 as `is_valid`, project_time, create_uid from fx_db.sop_project a 
where a.formation_date is not null and a.formation_date != '' 
and a.`id` not in (select `project_id` from fx_db.information_result where `title_id`=1816);