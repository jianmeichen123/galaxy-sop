﻿/*数据字典表增加 项目来源*/
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `created_time` , `updated_time` , `is_delete`) VALUES ('240', 'xhhl', '项目来源', '31', 'projectSource', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('234', 'projectSource', '事业部', '0', 'projectSource:0', '0', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('235', 'projectSource', 'FA', '1', 'projectSource:1', '1', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('236', 'projectSource', '创业者', '2', 'projectSource:2', '2', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('237', 'projectSource', '外部独立合伙人', '3', 'projectSource:3', '3', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('238', 'projectSource', '其他部门推荐', '4', 'projectSource:4', '4', '1456382861380', '1456382861380', '0');
INSERT INTO `fx_db`.`dict` (`id`, `parent_code`, `name`, `dict_value`, `dict_code`, `dict_sort`,  `created_time` , `updated_time` , `is_delete`) VALUES ('239', 'projectSource', '其他', '5', 'projectSource:5', '5', '1456382861380', '1456382861380', '0');


ALTER TABLE `fx_db`.`sop_project` 
CHANGE COLUMN `fa_flag` `fa_flag` VARCHAR(20) CHARACTER SET 'utf8' NOT NULL DEFAULT '0' COMMENT '项目是否来源于FA，默认0表示\"否\"，1表示\"是\"' ;


-- 项目来源 历史数据处理
UPDATE `fx_db`.`sop_project` SET `fa_flag`='projectSource:1' WHERE `fa_flag`='1';
UPDATE `fx_db`.`sop_project` SET `fa_flag`='projectSource:0' WHERE `fa_flag`='0';